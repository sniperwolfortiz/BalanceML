package com.balanceml.ui;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.balanceml.R;
import com.balanceml.game.GameView;

public class MainActivity extends AppCompatActivity {

    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep screen on during training
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        gameView = findViewById(R.id.gameView);
        TextView statusText = findViewById(R.id.statusText);

        gameView.setStatsListener((episode, eps, steps, loss, best) ->
            statusText.setText(String.format(
                "Episode %d  |  ε=%.3f  |  Steps %d\nLoss %.4f  |  Best Score %.1f",
                episode, eps, steps, loss, best))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameView.startGame();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.stopGame();
    }
}
