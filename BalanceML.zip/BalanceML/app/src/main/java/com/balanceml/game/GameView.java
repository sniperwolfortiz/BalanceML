package com.balanceml.game;

import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;

import com.balanceml.ml.DQNAgent;

/**
 * SurfaceView-equivalent using a regular View with postInvalidate().
 * Runs the game loop + RL training on a background thread.
 * Renders everything on the main thread via onDraw().
 */
public class GameView extends View {

    // ---- Rendering ----
    private final Paint targetPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boxPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint      = new Paint();
    private final Paint gridPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barBgPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Colors
    private static final int COL_BG       = 0xFF0D1117;
    private static final int COL_GRID     = 0xFF1A2233;
    private static final int COL_TARGET   = 0xFF00C8FF;
    private static final int COL_BOX      = 0xFFFF6B2B;
    private static final int COL_GOOD     = 0xFF39FF14;
    private static final int COL_TEXT     = 0xFFE0E0E0;
    private static final int COL_DIM      = 0xFF667788;

    // ---- Engine & Agent ----
    private final GameEngine engine = new GameEngine();
    private final DQNAgent   agent  = new DQNAgent();

    // ---- Game loop ----
    private Thread gameThread;
    private volatile boolean running = false;
    private static final long FRAME_MS = 16; // ~60 fps

    // ---- State snapshot for rendering (written by game thread, read by draw) ----
    private volatile float renderTargetY;
    private volatile float renderBoxY;
    private volatile float renderScore;
    private volatile float renderBalance;
    private volatile float renderEps;
    private volatile int   renderEpisode;
    private volatile int   renderSteps;
    private volatile float renderLoss;
    private volatile float renderBestScore;
    private volatile int   renderAction;
    private volatile float[] renderQValues = new float[3];
    private volatile float   renderScaleX;
    private volatile float   renderScaleY;

    // ---- Scale (set on first layout) ----
    private float scaleX = 1f;
    private float scaleY = 1f;

    // ---- Callback ----
    public interface StatsListener {
        void onStats(int episode, float eps, int steps, float loss, float best);
    }
    private StatsListener statsListener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initPaints();
        engine.setListener(score -> {
            // Episode ended — start a new one
            agent.step(engine.getState(), renderAction, score > 0 ? 0 : 0, engine.getState(), true);
            int ep = agent.getEpisodeCount();
            engine.setEpisode(ep);
            engine.reset();
            postStats();
        });
    }

    private void initPaints() {
        bgPaint.setColor(COL_BG);
        bgPaint.setStyle(Paint.Style.FILL);

        gridPaint.setColor(COL_GRID);
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(1f);

        targetPaint.setColor(COL_TARGET);
        targetPaint.setStyle(Paint.Style.FILL);

        glowPaint.setColor(COL_TARGET);
        glowPaint.setAlpha(60);
        glowPaint.setStyle(Paint.Style.FILL);
        glowPaint.setMaskFilter(new BlurMaskFilter(18, BlurMaskFilter.Blur.NORMAL));

        boxPaint.setColor(COL_BOX);
        boxPaint.setStyle(Paint.Style.FILL);

        textPaint.setColor(COL_TEXT);
        textPaint.setTypeface(Typeface.MONOSPACE);
        textPaint.setTextSize(28f);

        barBgPaint.setColor(0xFF222D3B);
        barBgPaint.setStyle(Paint.Style.FILL);

        barFillPaint.setColor(COL_GOOD);
        barFillPaint.setStyle(Paint.Style.FILL);
    }

    public void setStatsListener(StatsListener l) { statsListener = l; }

    // ---- Lifecycle ----
    public void startGame() {
        if (running) return;
        running = true;
        gameThread = new Thread(this::gameLoop, "GameLoop");
        gameThread.setDaemon(true);
        gameThread.start();
    }

    public void stopGame() {
        running = false;
        if (gameThread != null) {
            gameThread.interrupt();
            gameThread = null;
        }
    }

    private void gameLoop() {
        long lastTime = System.nanoTime();
        float[] prevState = engine.getState();

        while (running) {
            long now = System.nanoTime();
            float dt = (now - lastTime) / 1_000_000_000f;
            lastTime = now;
            dt = Math.min(dt, 0.05f); // cap at 50ms

            if (engine.isAlive()) {
                float[] state  = engine.getState();
                int action     = agent.selectAction(state);
                engine.tick(dt, action);
                float[] next   = engine.getState();
                float balance  = engine.getBalanceQuality();
                float reward   = balance > 0.85f ? 1.0f : (balance > 0.5f ? 0.3f : -0.2f);
                agent.step(state, action, reward, next, !engine.isAlive());

                // Update render snapshot
                float sw = getWidth()  > 0 ? getWidth()  / GameEngine.WORLD_W : 1f;
                float sh = getHeight() > 0 ? getHeight() / GameEngine.WORLD_H : 1f;
                renderScaleX   = sw;
                renderScaleY   = sh;
                renderTargetY  = engine.getTargetY();
                renderBoxY     = engine.getBoxY();
                renderScore    = engine.getScore();
                renderBalance  = balance;
                renderEps      = agent.getEpsilon();
                renderEpisode  = agent.getEpisodeCount();
                renderSteps    = agent.getStepCount();
                renderLoss     = agent.getLastLoss();
                renderBestScore= agent.getBestScore();
                renderAction   = action;
                float[] q = agent.getQValues(state);
                System.arraycopy(q, 0, renderQValues, 0, 3);
            }

            postInvalidate();

            // Throttle loop
            long elapsed = (System.nanoTime() - lastTime) / 1_000_000;
            long sleep   = FRAME_MS - elapsed;
            if (sleep > 0) {
                try { Thread.sleep(sleep); } catch (InterruptedException e) { break; }
            }
        }
    }

    // ---- Drawing ----
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float W = getWidth();
        float H = getHeight();
        float sx = W / GameEngine.WORLD_W;
        float sy = H / GameEngine.WORLD_H;

        // Background
        canvas.drawRect(0, 0, W, H, bgPaint);

        // Grid
        for (float gx = 0; gx < W; gx += 40 * sx)
            canvas.drawLine(gx, 0, gx, H, gridPaint);
        for (float gy = 0; gy < H; gy += 40 * sy)
            canvas.drawLine(0, gy, W, gy, gridPaint);

        // Colour the box differently by balance quality
        float bal = renderBalance;
        int boxColor = interpolateColor(COL_BOX, COL_GOOD, bal);
        boxPaint.setColor(boxColor);

        // Target
        float tY = renderTargetY * sy;
        float tHalf = GameEngine.TARGET_H / 2f * sy;
        float tWHalf = GameEngine.TARGET_W / 2f * sx;
        float cx = W / 2f;
        RectF targetRect = new RectF(cx - tWHalf, tY - tHalf, cx + tWHalf, tY + tHalf);
        // Glow
        canvas.drawRoundRect(new RectF(cx - tWHalf - 10, tY - tHalf - 6,
                cx + tWHalf + 10, tY + tHalf + 6), 8, 8, glowPaint);
        canvas.drawRoundRect(targetRect, 6, 6, targetPaint);

        // Box
        float bY = renderBoxY * sy;
        float bHalf = GameEngine.BOX_H / 2f * sy;
        float bWHalf = GameEngine.BOX_W / 2f * sx;
        RectF boxRect = new RectF(cx - bWHalf, bY - bHalf, cx + bWHalf, bY + bHalf);
        canvas.drawRoundRect(boxRect, 8, 8, boxPaint);

        // Connection line when close
        if (bal > 0.5f) {
            Paint linePaint = new Paint();
            linePaint.setColor(COL_GOOD);
            linePaint.setAlpha((int)(200 * bal));
            linePaint.setStrokeWidth(2f);
            canvas.drawLine(cx, bY + bHalf, cx, tY - tHalf, linePaint);
        }

        // HUD overlay
        drawHUD(canvas, W, H);
    }

    private void drawHUD(Canvas canvas, float W, float H) {
        float margin = 20f;
        float y = margin + 30f;
        textPaint.setTextSize(26f);

        // Episode & steps
        textPaint.setColor(COL_TEXT);
        canvas.drawText("EP " + renderEpisode + "   STEPS " + renderSteps, margin, y, textPaint);
        y += 36f;

        // Score
        textPaint.setColor(COL_GOOD);
        canvas.drawText(String.format("SCORE %.1f  BEST %.1f", renderScore, renderBestScore), margin, y, textPaint);
        y += 36f;

        // Epsilon
        textPaint.setColor(COL_DIM);
        textPaint.setTextSize(22f);
        canvas.drawText(String.format("ε=%.3f  loss=%.4f", renderEps, renderLoss), margin, y, textPaint);
        y += 34f;

        // Balance bar
        float barW = W - margin * 2f;
        float barH = 14f;
        RectF bgRect = new RectF(margin, y, margin + barW, y + barH);
        canvas.drawRoundRect(bgRect, 7, 7, barBgPaint);
        barFillPaint.setColor(interpolateColor(COL_BOX, COL_GOOD, renderBalance));
        RectF fillRect = new RectF(margin, y, margin + barW * renderBalance, y + barH);
        canvas.drawRoundRect(fillRect, 7, 7, barFillPaint);
        textPaint.setColor(COL_DIM);
        textPaint.setTextSize(18f);
        canvas.drawText("BALANCE", margin, y + barH + 18f, textPaint);
        y += barH + 26f;

        // Q-value bars
        String[] labels = {"▲ UP", "■ STAY", "▼ DOWN"};
        int[] colors = {0xFF00C8FF, 0xFFAAAAAA, 0xFFFF6B2B};
        float[] q = renderQValues;
        float qMin = q[0], qMax = q[0];
        for (float v : q) { qMin = Math.min(qMin, v); qMax = Math.max(qMax, v); }
        float qRange = Math.max(qMax - qMin, 0.01f);

        for (int i = 0; i < 3; i++) {
            float norm = (q[i] - qMin) / qRange;
            float bw = (W - margin * 2f) * 0.45f;
            RectF br = new RectF(margin, y, margin + bw, y + 18f);
            canvas.drawRoundRect(br, 4, 4, barBgPaint);
            Paint fp = new Paint();
            fp.setColor(i == renderAction ? colors[i] : dimColor(colors[i]));
            fp.setStyle(Paint.Style.FILL);
            RectF fr = new RectF(margin, y, margin + bw * norm, y + 18f);
            canvas.drawRoundRect(fr, 4, 4, fp);
            textPaint.setColor(i == renderAction ? 0xFFFFFFFF : COL_DIM);
            textPaint.setTextSize(20f);
            canvas.drawText(labels[i] + String.format(" %.2f", q[i]), margin + bw + 10f, y + 15f, textPaint);
            y += 26f;
        }
    }

    private int interpolateColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int)(ar + (br - ar) * t);
        int g = (int)(ag + (bg - ag) * t);
        int bv = (int)(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bv;
    }

    private int dimColor(int c) {
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        return 0xFF000000 | ((r / 3) << 16) | ((g / 3) << 8) | (b / 3);
    }

    private void postStats() {
        if (statsListener == null) return;
        mainHandler.post(() -> statsListener.onStats(
                agent.getEpisodeCount(), agent.getEpsilon(),
                agent.getStepCount(), agent.getLastLoss(), agent.getBestScore()));
    }
}
