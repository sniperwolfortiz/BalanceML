package com.balanceml.ml;

import java.util.Random;

/**
 * Deep Q-Network (DQN) agent.
 *
 * State space (5 inputs):
 *   0. boxY         - normalised box centre Y  [0..1]
 *   1. targetY      - normalised target Y       [0..1]
 *   2. delta        - (boxY - targetY)          [-1..1]
 *   3. boxVelocity  - normalised box velocity   [-1..1]
 *   4. targetVelocity - normalised target vel   [-1..1]
 *
 * Action space (3 outputs):
 *   0 = move UP
 *   1 = STAY
 *   2 = move DOWN
 */
public class DQNAgent {

    // ---- Hyperparameters ----
    private static final int   STATE_SIZE     = 5;
    private static final int   ACTION_SIZE    = 3;
    private static final int   BUFFER_CAP     = 10_000;
    private static final int   BATCH_SIZE     = 64;
    private static final int   TARGET_SYNC    = 200;  // steps between target-net sync
    private static final float GAMMA          = 0.95f;
    private static final float LR             = 1e-3f;
    private static final float EPS_START      = 1.0f;
    private static final float EPS_END        = 0.05f;
    private static final float EPS_DECAY      = 0.9995f;
    private static final int   MIN_REPLAY     = 256;

    private final NeuralNetwork online;   // trained every step
    private final NeuralNetwork target;   // frozen copy, synced periodically
    private final ReplayBuffer  buffer;
    private final Random rng = new Random();

    private float epsilon = EPS_START;
    private int   stepCount = 0;
    private int   episodeCount = 0;
    private float lastLoss = 0;
    private float bestScore = 0;
    private float totalReward = 0;

    public DQNAgent() {
        // 5 → 64 → 64 → 3
        online = new NeuralNetwork(STATE_SIZE, 64, 64, ACTION_SIZE);
        target = new NeuralNetwork(STATE_SIZE, 64, 64, ACTION_SIZE);
        target.copyWeightsFrom(online);
        buffer = new ReplayBuffer(BUFFER_CAP);
    }

    /** Choose action via ε-greedy policy. */
    public int selectAction(float[] state) {
        if (rng.nextFloat() < epsilon) {
            return rng.nextInt(ACTION_SIZE);
        }
        float[] q = online.forward(state);
        return argmax(q);
    }

    /** Store transition and train one step. */
    public void step(float[] state, int action, float reward,
                     float[] nextState, boolean done) {
        buffer.add(state, action, reward, nextState, done);
        totalReward += reward;
        stepCount++;

        if (done) {
            episodeCount++;
            if (totalReward > bestScore) bestScore = totalReward;
            totalReward = 0;
        }

        // Decay epsilon
        epsilon = Math.max(EPS_END, epsilon * EPS_DECAY);

        // Train
        if (buffer.canSample(MIN_REPLAY)) {
            trainBatch();
        }

        // Sync target network
        if (stepCount % TARGET_SYNC == 0) {
            target.copyWeightsFrom(online);
        }
    }

    private void trainBatch() {
        ReplayBuffer.Experience[] batch = buffer.sample(BATCH_SIZE);
        float totalLoss = 0;
        for (ReplayBuffer.Experience e : batch) {
            float[] nextQ = target.forward(e.nextState);
            float maxNextQ = e.done ? 0 : max(nextQ);
            float targetVal = e.reward + GAMMA * maxNextQ;
            online.trainStep(e.state, e.action, targetVal, LR);
            float[] currentQ = online.forward(e.state);
            float err = currentQ[e.action] - targetVal;
            totalLoss += err * err;
        }
        lastLoss = totalLoss / batch.length;
    }

    // ---- Getters for UI display ----
    public float getEpsilon()       { return epsilon; }
    public int   getEpisodeCount()  { return episodeCount; }
    public int   getStepCount()     { return stepCount; }
    public float getLastLoss()      { return lastLoss; }
    public float getBestScore()     { return bestScore; }
    public float[] getQValues(float[] state) { return online.forward(state); }
    public int   getActionSize()    { return ACTION_SIZE; }

    private int argmax(float[] arr) {
        int best = 0;
        for (int i = 1; i < arr.length; i++) if (arr[i] > arr[best]) best = i;
        return best;
    }
    private float max(float[] arr) {
        float m = arr[0];
        for (float v : arr) if (v > m) m = v;
        return m;
    }
}
