package com.balanceml.game;

/**
 * Pure physics simulation for the balance minigame.
 * No Android dependencies — fully testable in plain JVM.
 *
 * The target oscillates up and down with a sine wave (plus noise).
 * The box must stay ON TOP of the target (touching it from above).
 *
 * Coordinate system: Y increases DOWNWARD (screen coords).
 */
public class GameEngine {

    // --- World dimensions (logical units, scaled to screen by the View) ---
    public static final float WORLD_W = 360f;
    public static final float WORLD_H = 640f;

    // --- Object sizes ---
    public static final float TARGET_W  = 80f;
    public static final float TARGET_H  = 20f;
    public static final float BOX_W     = 50f;
    public static final float BOX_H     = 50f;

    // --- Physics ---
    private static final float BOX_SPEED      = 220f; // px/s the box can move
    private static final float TARGET_AMP     = 220f; // amplitude of oscillation
    private static final float TARGET_SPEED   = 1.4f; // frequency (rad/s base)
    private static final float GRAVITY        = 0f;   // optional: add gravity feel

    // --- State ---
    private float targetY;       // centre Y of the moving target
    private float targetVel;     // current velocity of target
    private float boxY;          // centre Y of the box
    private float boxVel;        // current velocity of box
    private float time;          // elapsed seconds

    // Noise/variation
    private float noiseOffset;
    private float noiseTime;
    private float speedMultiplier = 1.0f;

    // Score / episode
    private float score;
    private boolean alive;
    private int    tickCount;

    // Difficulty ramp
    private int episode = 0;

    // Callbacks
    public interface Listener {
        void onEpisodeEnd(float finalScore);
    }
    private Listener listener;

    public GameEngine() {
        reset();
    }

    public void setListener(Listener l) { this.listener = l; }

    public void setEpisode(int ep) {
        this.episode = ep;
        // Gradually increase target speed
        speedMultiplier = 1.0f + Math.min(ep * 0.04f, 1.5f);
    }

    /** Reset for a new episode. */
    public void reset() {
        targetY    = WORLD_H / 2f;
        boxY       = targetY - TARGET_H / 2f - BOX_H / 2f;
        targetVel  = 0;
        boxVel     = 0;
        time       = 0;
        score      = 0;
        alive      = true;
        tickCount  = 0;
        noiseOffset = (float)(Math.random() * 100);
        noiseTime   = 0;
    }

    /**
     * Advance simulation by dt seconds.
     * @param action 0=UP, 1=STAY, 2=DOWN
     */
    public void tick(float dt, int action) {
        if (!alive) return;
        time      += dt;
        noiseTime += dt;
        tickCount++;

        // --- Target movement: primary sine + secondary sine (Lissajous-like) ---
        float primary   = TARGET_AMP * (float) Math.sin(time * TARGET_SPEED * speedMultiplier);
        float secondary = (TARGET_AMP * 0.3f) * (float) Math.sin(time * TARGET_SPEED * 2.3f * speedMultiplier + 1.1f);
        float newTargetY = WORLD_H / 2f + primary + secondary;

        targetVel  = (newTargetY - targetY) / dt;
        targetY    = newTargetY;

        // --- Box movement (agent action) ---
        float accel = 0;
        if (action == 0) accel = -BOX_SPEED;   // UP
        else if (action == 2) accel = BOX_SPEED; // DOWN
        boxVel = accel; // direct velocity control (not force-based) for cleaner learning
        boxY  += boxVel * dt;

        // Clamp box to world
        boxY = Math.max(BOX_H / 2f, Math.min(WORLD_H - BOX_H / 2f, boxY));

        // --- Reward shaping ---
        float targetTop = targetY - TARGET_H / 2f;
        float boxBottom = boxY + BOX_H / 2f;
        float gap = Math.abs(boxBottom - targetTop);

        float reward;
        boolean onTarget = gap < 15f;

        if (onTarget) {
            reward = 1.0f - (gap / 15f) * 0.5f; // up to 1.0
            score += reward;
        } else {
            // Shaping: negative reward scaled by distance
            float dist = boxBottom - targetTop; // positive = box above target, negative = fallen through
            reward = -Math.min(Math.abs(dist) / WORLD_H, 1.0f) * 0.5f;
            score += reward;
        }

        // Episode ends after 8 seconds of sim time
        if (time >= 8.0f) {
            alive = false;
            if (listener != null) listener.onEpisodeEnd(score);
        }
    }

    // --- State vector for the agent ---
    public float[] getState() {
        return new float[]{
            boxY    / WORLD_H,           // normalised box Y
            targetY / WORLD_H,           // normalised target Y
            (boxY - targetY) / WORLD_H,  // delta Y
            boxVel  / (BOX_SPEED * 2f),  // normalised box velocity
            targetVel / (TARGET_AMP * TARGET_SPEED * 2f) // normalised target velocity
        };
    }

    // --- Getters ---
    public float getTargetY()  { return targetY; }
    public float getBoxY()     { return boxY; }
    public float getScore()    { return score; }
    public boolean isAlive()   { return alive; }
    public int  getTickCount() { return tickCount; }

    /** Returns how well the box is positioned: 1.0 = perfect, 0.0 = far off */
    public float getBalanceQuality() {
        float targetTop = targetY - TARGET_H / 2f;
        float boxBottom = boxY + BOX_H / 2f;
        float gap = Math.abs(boxBottom - targetTop);
        return Math.max(0f, 1f - gap / 60f);
    }
}
