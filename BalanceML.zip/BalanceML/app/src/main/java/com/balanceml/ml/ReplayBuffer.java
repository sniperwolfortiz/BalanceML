package com.balanceml.ml;

import java.util.Random;

/**
 * Circular experience replay buffer for DQN training.
 * Stores (state, action, reward, nextState, done) tuples.
 */
public class ReplayBuffer {

    public static class Experience {
        public final float[] state;
        public final int action;
        public final float reward;
        public final float[] nextState;
        public final boolean done;

        public Experience(float[] state, int action, float reward, float[] nextState, boolean done) {
            this.state     = state.clone();
            this.action    = action;
            this.reward    = reward;
            this.nextState = nextState.clone();
            this.done      = done;
        }
    }

    private final Experience[] buffer;
    private final int capacity;
    private int size = 0;
    private int index = 0;
    private final Random rng = new Random();

    public ReplayBuffer(int capacity) {
        this.capacity = capacity;
        this.buffer   = new Experience[capacity];
    }

    public void add(float[] state, int action, float reward, float[] nextState, boolean done) {
        buffer[index] = new Experience(state, action, reward, nextState, done);
        index = (index + 1) % capacity;
        size  = Math.min(size + 1, capacity);
    }

    public Experience[] sample(int batchSize) {
        batchSize = Math.min(batchSize, size);
        Experience[] batch = new Experience[batchSize];
        for (int i = 0; i < batchSize; i++) {
            batch[i] = buffer[rng.nextInt(size)];
        }
        return batch;
    }

    public int size() { return size; }
    public boolean canSample(int minSize) { return size >= minSize; }
}
