package com.balanceml.ml;

import java.util.Random;

/**
 * Lightweight feed-forward neural network in pure Java.
 * Architecture: input -> hidden1 -> hidden2 -> output
 * Activation: ReLU for hidden layers, linear for output (Q-values).
 */
public class NeuralNetwork {

    private final int[] layerSizes;
    private final float[][][] weights; // weights[layer][to][from]
    private final float[][] biases;    // biases[layer][to]
    private final float[][] activations;
    private final Random rng = new Random(42);

    public NeuralNetwork(int... layerSizes) {
        this.layerSizes = layerSizes;
        int L = layerSizes.length;
        weights = new float[L - 1][][];
        biases = new float[L - 1][];
        activations = new float[L][];

        for (int l = 0; l < L - 1; l++) {
            int out = layerSizes[l + 1];
            int in  = layerSizes[l];
            weights[l] = new float[out][in];
            biases[l]  = new float[out];
            activations[l] = new float[layerSizes[l]];

            // He initialisation
            float scale = (float) Math.sqrt(2.0 / in);
            for (int i = 0; i < out; i++) {
                for (int j = 0; j < in; j++) {
                    weights[l][i][j] = (float) rng.nextGaussian() * scale;
                }
            }
        }
        activations[L - 1] = new float[layerSizes[L - 1]];
    }

    /** Forward pass; returns a copy of output Q-values. */
    public float[] forward(float[] input) {
        System.arraycopy(input, 0, activations[0], 0, input.length);
        int L = layerSizes.length;
        for (int l = 0; l < L - 1; l++) {
            int out = layerSizes[l + 1];
            int in  = layerSizes[l];
            boolean isOutput = (l == L - 2);
            for (int i = 0; i < out; i++) {
                float sum = biases[l][i];
                for (int j = 0; j < in; j++) {
                    sum += weights[l][i][j] * activations[l][j];
                }
                activations[l + 1][i] = isOutput ? sum : relu(sum);
            }
        }
        return activations[L - 1].clone();
    }

    /**
     * Single-sample gradient descent update for DQN.
     * We do backprop only on the chosen action output neuron.
     */
    public void trainStep(float[] input, int action, float target, float lr) {
        // Forward pass (fills activations)
        float[] qValues = forward(input);

        int L = layerSizes.length;
        // Output error only for the chosen action
        float[] outError = new float[layerSizes[L - 1]];
        outError[action] = qValues[action] - target; // MSE gradient

        // Backprop through layers
        float[] deltaNext = outError;
        for (int l = L - 2; l >= 0; l--) {
            int out = layerSizes[l + 1];
            int in  = layerSizes[l];
            float[] delta = deltaNext;
            float[] deltaCurr = new float[in];

            for (int i = 0; i < out; i++) {
                for (int j = 0; j < in; j++) {
                    deltaCurr[j] += weights[l][i][j] * delta[i];
                    weights[l][i][j] -= lr * delta[i] * activations[l][j];
                }
                biases[l][i] -= lr * delta[i];
            }

            // Apply ReLU derivative for previous layer (skip for input)
            if (l > 0) {
                for (int j = 0; j < in; j++) {
                    if (activations[l][j] <= 0) deltaCurr[j] = 0;
                }
            }
            deltaNext = deltaCurr;
        }
    }

    /** Copy weights FROM another network (for target network sync). */
    public void copyWeightsFrom(NeuralNetwork src) {
        for (int l = 0; l < weights.length; l++) {
            for (int i = 0; i < weights[l].length; i++) {
                System.arraycopy(src.weights[l][i], 0, weights[l][i], 0, weights[l][i].length);
                biases[l][i] = src.biases[l][i];
            }
        }
    }

    private float relu(float x) { return Math.max(0, x); }
}
